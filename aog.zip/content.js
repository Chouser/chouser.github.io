// Amazon Order Guard — content script
//
// Injected on every amazon.com page at document_start (not just checkout
// URLs) because Amazon's checkout is a client-side single-page app (SPC) —
// scoping injection to a narrow URL pattern risks missing the moment a user
// arrives at checkout via in-page navigation. The cost is negligible: the
// heavy logic below only ever activates when the page actually looks like
// checkout.
//
// Two independent safety layers:
//   1. Interception — block the real "place order" action.
//   2. Canary — if the page looks like checkout but layer 1 can't find
//      anything to intercept, say so loudly instead of doing nothing.

(() => {
  'use strict';

  // ---- Detection targets -------------------------------------------------
  //
  // Ranked, redundant selectors for the final order-submit control. All of
  // these currently resolve to the same element or its wrapper — any single
  // match is sufficient. Ordered by how likely each is to survive a redesign:
  // declarative action bindings and test ids tend to outlive numeric/class
  // names, which Amazon changes more freely.
  const BUTTON_SELECTORS = [
    '[data-action="place-order"]',
    '[data-testid="SPC_selectPlaceOrder"]',
    '#submitOrderButtonId',
    '#placeOrder',
    'input[type="submit"][value="Place your order"]',
    'button[aria-label="Place your order" i]'
  ];

  const TEXT_FALLBACK = /^\s*place your order\s*$/i;

  // Weak signals used ONLY to drive the canary (never to decide whether to
  // block something) — i.e. "are we probably somewhere inside checkout?"
  const CHECKOUT_URL_HINTS = ['/checkout', '/buy/spc', '/gp/buy'];
  const CHECKOUT_TEXT_HINTS = [/secure checkout/i, /place your order/i];
  const CHECKOUT_MARKUP_HINT = '[class*="spc-"], [data-testid*="SPC"]';

  // Signals that we're on a step BEFORE the final review page — e.g. an
  // upsell/cross-sell carousel Amazon shows on the way into checkout. These
  // pages can still match the loose checks above (shared URL prefix, same
  // "Secure checkout" header chrome), so this exists to keep the canary
  // quiet until the shopper has actually reached the page that should have
  // a "Place your order" control. General principle: a "Continue to
  // checkout" control existing at all means, by definition, checkout hasn't
  // been reached yet.
  const INTERMEDIATE_STEP_SELECTORS = ['[name="checkout-byg-ptc-button"]'];
  const INTERMEDIATE_STEP_TEXT = /^\s*continue to checkout\s*$/i;

  function looksLikeIntermediateStep() {
    if (
      INTERMEDIATE_STEP_SELECTORS.some((sel) => {
        try {
          return !!document.querySelector(sel);
        } catch (e) {
          return false;
        }
      })
    ) {
      return true;
    }
    const candidates = document.querySelectorAll('a, button, input[type="submit"], input[type="button"], [role="button"]');
    for (const el of candidates) {
      const label = (el.value || el.textContent || '').trim();
      if (INTERMEDIATE_STEP_TEXT.test(label)) return true;
    }
    return false;
  }

  const CANARY_GRACE_MS = 5000;   // how long "checkout-like, no button" has to persist before alerting
  const CANARY_POLL_MS = 1500;
  const MUTATION_DEBOUNCE_MS = 400;
  const INTERCEPT_DEBOUNCE_MS = 1500; // collapse click+submit+enter firing for the same attempt

  // ---- State ---------------------------------------------------------------

  let settings = { ...DEFAULT_SETTINGS };
  let lastInterceptAt = 0;
  let buttonMissingSince = null; // set only while checkout-like AND no button found
  let anomalyAlerted = false;
  let mutationTimer = null;

  chrome.storage.sync.get(DEFAULT_SETTINGS, (stored) => { settings = stored; });
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'sync') {
      for (const key of Object.keys(changes)) settings[key] = changes[key].newValue;
    }
  });

  // ---- Button detection ------------------------------------------------------

  function findOrderButton(root = document) {
    for (const selector of BUTTON_SELECTORS) {
      try {
        const el = root.querySelector(selector);
        if (el) return el;
      } catch (e) {
        /* a selector never gets to take the whole guard down */
      }
    }
    const candidates = root.querySelectorAll('input[type="submit"], button, [role="button"]');
    for (const el of candidates) {
      const label = (el.value || el.textContent || '').trim();
      if (TEXT_FALLBACK.test(label)) return el;
    }
    return null;
  }

  function elementMatchesOrderButton(el) {
    if (!el || el.nodeType !== 1) return false;
    for (const selector of BUTTON_SELECTORS) {
      try {
        if (el.closest(selector)) return true;
      } catch (e) { /* ignore */ }
    }
    const label = (el.value || el.textContent || '').trim();
    return TEXT_FALLBACK.test(label);
  }

  // ---- Checkout-context heuristic (canary only) -------------------------------

  function looksLikeCheckoutPage() {
    const path = location.pathname.toLowerCase();
    if (CHECKOUT_URL_HINTS.some((hint) => path.includes(hint))) return true;
    if (document.querySelector(CHECKOUT_MARKUP_HINT)) return true;
    const bodyText = document.body ? document.body.innerText.slice(0, 5000) : '';
    return CHECKOUT_TEXT_HINTS.some((re) => re.test(bodyText));
  }

  // ---- Best-effort order context for the notification (never blocks anything) --

  function extractOrderContext() {
    try {
      const totalRegex = /\$[\d,]+\.\d{2}/;
      const candidates = document.querySelectorAll(
        '[data-testid*="order-total" i], [id*="grand-total" i], [class*="grand-total" i], [class*="order-total" i]'
      );
      for (const el of candidates) {
        const match = el.textContent.match(totalRegex);
        if (match) return { total: match[0] };
      }
    } catch (e) {
      /* best-effort only — absence of a total should never block the hold */
    }
    return {};
  }

  // ---- Holding the order ---------------------------------------------------

  function holdOrder(trigger) {
    const now = Date.now();
    if (now - lastInterceptAt < INTERCEPT_DEBOUNCE_MS) return;
    lastInterceptAt = now;

    showHoldOverlay();

    chrome.runtime.sendMessage({
      type: 'ORDER_HELD',
      data: { url: location.href, timestamp: now, trigger, ...extractOrderContext() }
    });
  }

  function showHoldOverlay() {
    // Redirecting only happens after the order was already blocked
    // (preventDefault fired before this function was even called), so it
    // doesn't let anything through — it just moves the tab off checkout.
    if (document.getElementById('aog-overlay')) return;
    const overlay = document.createElement('div');
    overlay.id = 'aog-overlay';
    overlay.innerHTML = `
      <div class="aog-card" role="alert">
        <button type="button" class="aog-close" aria-label="Dismiss">&times;</button>
        <div class="aog-title">✅ ${escapeHtml(settings.holdTitle)}</div>
        <div class="aog-body">${escapeHtml(settings.holdBody)}</div>
        <button type="button" class="aog-ok">OK</button>
      </div>
    `;
    (document.body || document.documentElement).appendChild(overlay);

    function dismiss() {
      overlay.remove();
      document.removeEventListener('keydown', onKeydown, true);
    }
    function redirect() {
      overlay.remove();
      document.removeEventListener('keydown', onKeydown, true);
      window.location.href = safeRedirectUrl(settings.redirectUrl);
    }

    // Various ways to leave the hold overlay.
    function onKeydown(e) {
      if (e.key === 'Escape') dismiss();
    }
    overlay.addEventListener('click', (e) => { if (e.target === overlay) redirect(); });
    overlay.querySelector('.aog-close').addEventListener('click', redirect);
    overlay.querySelector('.aog-ok').addEventListener('click', redirect);
    document.addEventListener('keydown', onKeydown, true);
  }

  function safeRedirectUrl(url) {
    try {
      return new URL(url).href;
    } catch (e) {
      return DEFAULT_SETTINGS.redirectUrl;
    }
  }

  function escapeHtml(str) {
    const div = document.createElement('div');
    div.textContent = String(str == null ? '' : str);
    return div.innerHTML;
  }

  // ---- Interception: click, native submit, and Enter-to-submit ----------------
  //
  // Registered on `document` in the CAPTURING phase at document_start. Capture
  // travels root -> target, so a document-level capturing listener fires before
  // any listener Amazon attaches to the button itself, regardless of whether
  // theirs is capture or bubble phase — as long as we're registered before any
  // OTHER document-level capturing listener wins that same race, which is why
  // this file is injected as early as run_at allows.
  //
  // Delegation (checking event.target on every event, rather than holding a
  // reference to one element) also protects against React/SPA re-renders that
  // silently swap the DOM node out from under a directly-attached listener.

  document.addEventListener(
    'click',
    (event) => {
      if (elementMatchesOrderButton(event.target)) {
        event.preventDefault();
        event.stopImmediatePropagation();
        event.stopPropagation();
        holdOrder('click');
      }
    },
    true
  );

  document.addEventListener(
    'submit',
    (event) => {
      const form = event.target;
      if (form && typeof form.querySelector === 'function' && findOrderButton(form)) {
        event.preventDefault();
        event.stopImmediatePropagation();
        event.stopPropagation();
        holdOrder('submit');
      }
    },
    true
  );

  // Enter-to-submit from a form field never fires a click on the button, so it
  // needs its own check — same "does this form contain the order button" test.
  document.addEventListener(
    'keydown',
    (event) => {
      if (event.key !== 'Enter') return;
      const active = document.activeElement;
      if (!active || active.tagName === 'TEXTAREA') return;
      const form = active.closest && active.closest('form');
      if (form && findOrderButton(form)) {
        event.preventDefault();
        event.stopImmediatePropagation();
        event.stopPropagation();
        holdOrder('enter');
      }
    },
    true
  );

  // ---- Canary: alert if checkout-like but nothing to intercept ----------------

  function runCanaryCheck() {
    const now = Date.now();
    if (!looksLikeCheckoutPage() || looksLikeIntermediateStep()) {
      buttonMissingSince = null;
      anomalyAlerted = false;
      return;
    }

    const found = !!findOrderButton();
    if (found) {
      // Button is there — nothing to warn about, and clear any prior episode
      // so a *future* disappearance gets its own fresh grace period.
      buttonMissingSince = null;
      anomalyAlerted = false;
      return;
    }

    // Checkout-like page, no matching button right now.
    if (buttonMissingSince === null) buttonMissingSince = now;

    if (!anomalyAlerted && now - buttonMissingSince > CANARY_GRACE_MS) {
      anomalyAlerted = true;
      chrome.runtime.sendMessage({
        type: 'GUARD_ANOMALY',
        data: {
          url: location.href,
          timestamp: now,
          reason: `Page looks like checkout but no "place order" control matched any known selector for over ${Math.round(CANARY_GRACE_MS / 1000)}s.`
        }
      });
    }
  }

  setInterval(runCanaryCheck, CANARY_POLL_MS);

  const observer = new MutationObserver(() => {
    if (mutationTimer) return;
    mutationTimer = setTimeout(() => {
      mutationTimer = null;
      runCanaryCheck();
    }, MUTATION_DEBOUNCE_MS);
  });

  function startObserving() {
    observer.observe(document.documentElement, { childList: true, subtree: true });
  }
  if (document.documentElement) startObserving();
  else document.addEventListener('DOMContentLoaded', startObserving, { once: true });

  // ---- Cart cleanup (runs only on a page opened specifically for this) -------
  //
  // background.js opens a hidden background tab to the cart page with the
  // cleanup mode encoded in the URL hash when an order is held (if a mode
  // other than "off" is set in Options). This block detects that flag and,
  // ONLY on that tab, runs the requested cleanup.
  //
  // "save_for_later" is wired up and safe: it just clicks Amazon's own
  // reversible "Save for later" control, confirmed against real DOM.
  // "wishlist" is not fully wired up yet — see the TODO in runCartCleanup().

  (function maybeRunCartCleanup() {
    const match = location.hash.match(/aog-move=([^&]+)/);
    if (!match) return;
    if (window.__aogCartCleanupStarted) return;
    window.__aogCartCleanupStarted = true;

    let payload;
    try {
      payload = JSON.parse(decodeURIComponent(match[1]));
    } catch (e) {
      console.error('[Amazon Order Guard] Could not parse cart-cleanup flag from the URL:', e);
      return;
    }
    const { mode, wishlistName } = payload;
    history.replaceState(null, '', location.pathname + location.search); // consume the flag

    const kickoff = () => runCartCleanup(mode, wishlistName).catch((e) => {
      console.error('[Amazon Order Guard] Cart cleanup crashed:', e);
      chrome.runtime.sendMessage({
        type: 'CART_CLEANUP_RESULT',
        data: { mode, wishlistName, moved: 0, addedOnly: 0, failed: 0, error: String(e) }
      });
    });

    if (document.readyState === 'complete') kickoff();
    else window.addEventListener('load', kickoff, { once: true });
  })();

  function sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  function waitFor(predicate, timeoutMs) {
    return new Promise((resolve, reject) => {
      const start = Date.now();
      (function poll() {
        const result = predicate();
        if (result) return resolve(result);
        if (Date.now() - start > timeoutMs) return reject(new Error('timeout'));
        setTimeout(poll, 150);
      })();
    });
  }

  function escapeRegex(s) {
    return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  }

  function findByVisibleText(root, text) {
    const re = new RegExp(`^\\s*${escapeRegex(text)}\\s*$`, 'i');
    const candidates = root.querySelectorAll('a, button, input[type="submit"], input[type="button"], [role="button"]');
    for (const el of candidates) {
      const label = (el.value || el.textContent || el.getAttribute('aria-label') || '').trim();
      if (re.test(label)) return el;
    }
    return null;
  }

  // Candidate containers for "just the active cart items" — deliberately
  // NOT falling back to `document` if none of these match. Searching the
  // whole page is what caused wrong items (recommendations, saved-for-later)
  // to get matched last time. One inferred guess is included below, but
  // it's unverified — see README. Aborting is the safe failure mode here.
  const CART_ROOT_SELECTORS = ['#sc-active-cart', '#activeCartViewForm'];

  function findCartItemsRoot() {
    for (const sel of CART_ROOT_SELECTORS) {
      try {
        const el = document.querySelector(sel);
        if (el) return el;
      } catch (e) {
        /* ignore */
      }
    }
    return null;
  }

  // Confirmed: the saved-for-later item's Delete control uses the exact
  // same data-feature-id as an active cart item's Delete control
  // (item-delete-button) — so this root distinction is what actually keeps
  // the two scopes apart, not the leaf selector. Still an inferred guess
  // for the container itself, same as CART_ROOT_SELECTORS above.
  const SAVED_ITEMS_ROOT_SELECTORS = ['#sc-saved-cart'];

  function findSavedItemsRoot() {
    for (const sel of SAVED_ITEMS_ROOT_SELECTORS) {
      try {
        const el = document.querySelector(sel);
        if (el) return el;
      } catch (e) {
        /* ignore */
      }
    }
    return null;
  }

  function findListOption(name) {
    const re = new RegExp(`^\\s*${escapeRegex(name)}\\s*$`, 'i');
    const candidates = document.querySelectorAll('[id*="cldd-list-name" i], [role="option"], li, a, button, span, div');
    for (const el of candidates) {
      if (el.children.length > 2) continue; // prefer leaf-ish elements over big wrapping containers
      const label = (el.textContent || '').trim();
      if (re.test(label)) return el;
    }
    return null;
  }

  // Confirmed from a real cart item's action row (2026-08): the Delete and
  // Save for later controls carry specific, semantic feature ids — much
  // more trustworthy than matching on generic "Delete" text, which is also
  // used elsewhere on the cart page (recommendations, saved-for-later).
  // Text matching is kept only as a fallback tier in case Amazon renames
  // these ids later.
  const DELETE_BUTTON_SELECTOR = '[data-feature-id="item-delete-button"]';
  const SAVE_FOR_LATER_SELECTOR = '[data-feature-id="save-for-later-action"]';

  function findAllDeleteControls(root) {
    const byFeatureId = Array.from(root.querySelectorAll(DELETE_BUTTON_SELECTOR));
    if (byFeatureId.length > 0) return byFeatureId;
    const re = /^\s*delete\s*$/i;
    const candidates = root.querySelectorAll('a, button, input[type="submit"], input[type="button"], [role="button"]');
    const out = [];
    for (const el of candidates) {
      const label = (el.value || el.textContent || el.getAttribute('aria-label') || '').trim();
      if (re.test(label)) out.push(el);
    }
    return out;
  }

  function findAllSaveForLaterControls(root) {
    const byFeatureId = Array.from(root.querySelectorAll(SAVE_FOR_LATER_SELECTOR));
    if (byFeatureId.length > 0) return byFeatureId;
    const re = /^\s*save for later\s*$/i;
    const candidates = root.querySelectorAll('a, button, input[type="submit"], input[type="button"], [role="button"]');
    const out = [];
    for (const el of candidates) {
      const label = (el.value || el.textContent || el.getAttribute('aria-label') || '').trim();
      if (re.test(label)) out.push(el);
    }
    return out;
  }

  function findItemContainer(deleteEl) {
    const candidateSelectors = ['[data-asin]', '[role="listitem"]', '[class*="sc-list-item" i]', '[id*="sc-list-item" i]', 'li'];
    for (const sel of candidateSelectors) {
      const found = deleteEl.closest(sel);
      if (found) return found;
    }
    let el = deleteEl;
    for (let i = 0; i < 6 && el.parentElement; i++) el = el.parentElement;
    return el;
  }

  // Stable identity for an item, straight from Amazon's own action payload
  // (confirmed via real DOM: the same data-sc-item-action JSON sits on the
  // Delete and Save-for-later controls, carrying an itemID). Used instead of
  // a DOM-node flag so progress survives Amazon re-rendering a row mid-flow
  // — see moveSavedForLaterItemsToWishlist().
  function getItemId(el) {
    const actionEl = el.closest('[data-sc-item-action]');
    if (!actionEl) return null;
    try {
      return JSON.parse(actionEl.getAttribute('data-sc-item-action')).itemID || null;
    } catch (e) {
      return null;
    }
  }

  // Confirmed via real DOM (Saved-for-later section): each item's "Add to
  // list" control sits next to a per-item confirmation element,
  // `.add-to-list-success-label` (hidden via the `aok-hidden` class until it
  // works), containing `.added-list-name` with the actual list name it
  // landed in. That's a specific, reliable success signal — far better than
  // guessing from whether a dropdown closed — so this checks both that the
  // label became visible AND that the name it reports matches the
  // configured list, before Delete is ever clicked.
  async function tryAddSavedItemToList(container, wishlistName) {
    const addBtn = findByVisibleText(container, 'Add to list') || findByVisibleText(container, 'Add to List');
    if (!addBtn) return { ok: false };
    addBtn.click();

    let optionEl;
    try {
      optionEl = await waitFor(() => findListOption(wishlistName), 4000);
    } catch (e) {
      return { ok: false };
    }
    optionEl.click();

    const confirmed = await waitFor(() => {
      const label = container.querySelector('.add-to-list-success-label');
      if (!label || label.classList.contains('aok-hidden')) return false;
      const nameEl = label.querySelector('.added-list-name');
      const addedName = (nameEl ? nameEl.textContent : '').trim();
      return !wishlistName || addedName.toLowerCase() === wishlistName.trim().toLowerCase();
    }, 4000)
      .then(() => true)
      .catch(() => false);

    return { ok: true, confirmed };
  }

  async function runCartCleanup(mode, wishlistName) {
    let root;
    try {
      root = await waitFor(() => findCartItemsRoot(), 6000);
    } catch (e) {
      console.error(
        '[Amazon Order Guard] Could not find a scoped cart-items container ' +
        `(tried: ${CART_ROOT_SELECTORS.join(', ')}) — aborting instead of searching the ` +
        'whole page, since that previously matched unrelated buttons elsewhere on the cart page.'
      );
      chrome.runtime.sendMessage({
        type: 'CART_CLEANUP_RESULT',
        data: { mode, wishlistName, moved: 0, addedOnly: 0, failed: 0, aborted: true }
      });
      return;
    }

    if (mode === 'save_for_later') {
      try {
        await waitFor(() => findAllSaveForLaterControls(root).length > 0, 4000);
      } catch (e) {
        // nothing found in time — could just be an empty cart, that's fine
      }
      const { saved, failed } = await runSaveForLater(root);
      chrome.runtime.sendMessage({
        type: 'CART_CLEANUP_RESULT',
        data: { mode, moved: saved, addedOnly: 0, failed }
      });
      return;
    }

    // mode === 'wishlist' — two stages, since Amazon doesn't expose "Add to
    // list" on active cart items directly (confirmed via real DOM): Save
    // for later moves each item into the Saved-for-later section, and only
    // from there can it be added to a list and then deleted. If stage two
    // can't find its container, items may be left sitting in Saved for
    // later rather than back in the cart or on the list — recoverable via
    // "Move to cart" there, not lost, but worth knowing as the one
    // in-between state this can leave things in.
    try {
      await waitFor(() => findAllDeleteControls(root).length > 0, 4000);
    } catch (e) {
      // nothing found in time — could just be an empty cart, that's fine
    }

    const activeItemCount = findAllDeleteControls(root).length;
    if (activeItemCount === 0) {
      chrome.runtime.sendMessage({
        type: 'CART_CLEANUP_RESULT',
        data: { mode, wishlistName, moved: 0, addedOnly: 0, failed: 0 }
      });
      return;
    }

    await runSaveForLater(root);

    let savedRoot;
    try {
      savedRoot = await waitFor(() => findSavedItemsRoot(), 6000);
    } catch (e) {
      console.error(
        '[Amazon Order Guard] Items were saved for later, but the Saved-for-later container ' +
        `wasn't found (tried: ${SAVED_ITEMS_ROOT_SELECTORS.join(', ')}) — stopping before the list step. ` +
        'Items are sitting in Saved for later, not lost.'
      );
      chrome.runtime.sendMessage({
        type: 'CART_CLEANUP_RESULT',
        data: { mode, wishlistName, moved: 0, addedOnly: 0, failed: 0, aborted: true, reason: 'no_saved_root_found' }
      });
      return;
    }

    const { moved, addedOnly, failed } = await moveSavedForLaterItemsToWishlist(savedRoot, wishlistName);
    chrome.runtime.sendMessage({
      type: 'CART_CLEANUP_RESULT',
      data: { mode, wishlistName, moved, addedOnly, failed }
    });
  }

  // Wired up and safe: Save for later is Amazon's own reversible action, and
  // this doesn't need the "confirm before delete" caution the wishlist path
  // needs, since there's nothing destructive happening — an item that
  // doesn't visibly disappear just gets tagged and left alone.
  async function runSaveForLater(root) {
    let saved = 0;
    let failed = 0;
    let consecutiveFailures = 0;
    const maxIterations = 50; // absolute safety cap

    for (let i = 0; i < maxIterations; i++) {
      const remaining = findAllSaveForLaterControls(root).filter((el) => !findItemContainer(el).dataset.aogSkip);
      if (remaining.length === 0) break;

      const btn = remaining[0];
      const container = findItemContainer(btn);
      const countBefore = remaining.length;

      try {
        btn.click();
        await sleep(700); // let the cart re-render before checking
        const countAfter = findAllSaveForLaterControls(root).filter((el) => !findItemContainer(el).dataset.aogSkip).length;
        if (countAfter < countBefore) {
          saved++;
          consecutiveFailures = 0;
        } else {
          failed++;
          container.dataset.aogSkip = '1';
          consecutiveFailures++;
        }
      } catch (e) {
        console.error('[Amazon Order Guard] Save for later failed for one item:', e);
        failed++;
        container.dataset.aogSkip = '1';
        consecutiveFailures++;
      }

      if (consecutiveFailures > 5) break; // something's fundamentally not working — stop rather than loop pointlessly
    }

    return { saved, failed };
  }

  // Now wired up from runCartCleanup() above, using `root` = the
  // Saved-for-later container. Confirmed selectors throughout: Delete here
  // uses the same data-feature-id as the active cart ("item-delete-button"),
  // so the root scoping is what keeps these two stages from crossing paths.
  async function moveSavedForLaterItemsToWishlist(root, wishlistName) {
    let moved = 0;
    let addedOnly = 0;
    let failed = 0;
    let consecutiveFailures = 0;
    const maxIterations = 50; // absolute safety cap, independent of everything else below
    // Tracks progress by item id rather than a DOM-node dataset flag: the
    // Add-to-list popover interaction can cause Amazon to re-render a saved
    // item's row, which produces a fresh node without whatever flag was set
    // on the old one — the loop would then "discover" the same item forever
    // and never hit any of the return paths below, so nothing ever reports
    // back and the tab just sits there until background.js's 45s sweep
    // kills it. That symptom (stuck after save-for-later, generic timeout
    // notification) is what this guards against.
    const handledIds = new Set();

    for (let i = 0; i < maxIterations; i++) {
      const remaining = findAllDeleteControls(root).filter((el) => {
        const id = getItemId(el);
        return id ? !handledIds.has(id) : !findItemContainer(el).dataset.aogSkip;
      });
      if (remaining.length === 0) break;

      const delBtn = remaining[0];
      const container = findItemContainer(delBtn);
      const itemId = getItemId(delBtn);
      const markHandled = () => { if (itemId) handledIds.add(itemId); else container.dataset.aogSkip = '1'; };

      try {
        const result = await tryAddSavedItemToList(container, wishlistName);
        if (!result.ok) {
          failed++;
          consecutiveFailures++;
          markHandled();
          continue;
        }
        await sleep(400);
        if (result.confirmed) {
          delBtn.click();
          moved++;
          consecutiveFailures = 0;
          markHandled();
          await sleep(800); // let the section re-render before re-querying
        } else {
          // Couldn't confirm the add went through — leave it rather than
          // risk deleting something that was never saved.
          addedOnly++;
          consecutiveFailures++;
          markHandled();
        }
      } catch (e) {
        console.error('[Amazon Order Guard] Wishlist move failed for one item:', e);
        failed++;
        consecutiveFailures++;
        markHandled();
      }

      // Mirrors runSaveForLater()'s safety net — stop and report rather
      // than grinding through maxIterations while the background tab's
      // 45s timeout ticks down regardless.
      if (consecutiveFailures > 5) break;
    }

    return { moved, addedOnly, failed };
  }
})();
