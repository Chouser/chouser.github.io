# Amazon Order Guard

Holds Amazon checkout for approval instead of placing the order, and pushes an alert to a phone via [ntfy.sh](https://ntfy.sh).

## How it works

Runs on every amazon.com page (not just checkout URLs, since checkout is a client-side app you can navigate into without a full page load). It watches specifically for the final **"Place your order"** control — both the "Buy Now" and cart-checkout paths land on the same control, since both go through Amazon's shared single-page checkout (SPC). When that control is clicked, submitted, or triggered via Enter key, the action is blocked before anything reaches Amazon, an on-page message is shown, and a phone alert goes out. If the page looks like checkout but nothing matching that control can be found, a separate "check needed" alert fires instead of silently doing nothing.

## Install (Chrome / Edge)

1. Unzip this folder somewhere permanent (don't delete it after installing — Chrome loads the extension from this location).
2. Go to `chrome://extensions`.
3. Turn on **Developer mode** (top right).
4. Click **Load unpacked** and select the unzipped `amazon-order-guard` folder.
5. The options page opens automatically on first install. Click the extension's toolbar icon any time after to reopen it.

## Set up the phone alert

Phone + local alerts are on by default and can be turned off entirely with one checkbox in Options ("Send phone + local alerts when an order is held") — the block itself and the wishlist cleanup below both work independently of this setting. The one exception is the "guard needs attention" anomaly alert (see Robustness notes) — that one stays on regardless, since it's about the tool itself possibly failing rather than a purchase happening.

1. Install the **ntfy** app ([iOS](https://apps.apple.com/us/app/ntfy/id1625396347) / [Android](https://play.google.com/store/apps/details?id=io.heckel.ntfy)), or just open `https://ntfy.sh/<your-topic>` in a phone browser.
2. Subscribe to a topic — pick something long and specific (e.g. `cart-guard-7f3ka9x`), not `cart` or `amazon`. ntfy.sh topics are public by default: anyone who knows the exact name can read it.
3. Paste that same topic into the extension's options page. Leave the server as `https://ntfy.sh` unless you're self-hosting.
4. Click **Save changes**, then **Send test alert** to confirm it reaches the phone.

## Cart cleanup

Off by default. "When an order is held," in Options, has three settings:

- **Do nothing to the cart** — default.
- **Save all items for later** — Amazon's own reversible "Save for later," confirmed against real DOM (`data-feature-id="save-for-later-action"`). "Move to cart" from the Saved for later section undoes it instantly.
- **Move items to a wish list** — a two-stage flow, both stages now confirmed against real DOM: it Saves each item for later first (active cart items don't expose "Add to list" directly), then from the Saved-for-later section clicks "Add to list" → picks the named list → and only clicks Delete once it can confirm the add actually landed on the *right* list. That confirmation isn't a guess anymore — Amazon shows a per-item label (`.add-to-list-success-label`, with the actual list name in `.added-list-name`) once an add succeeds, and this checks both that the label appeared and that the name matches before deleting anything. If it can't confirm that, the item is left as-is rather than risk deleting something that was never saved. The one honest caveat left: if stage two can't find the Saved-for-later container at all, items end up sitt­ing there rather than back in the cart or on the list — not lost (recoverable with "Move to cart"), but not the intended end state either; the notification will say so explicitly if it happens.

Either mode opens the cart page in a hidden background tab (so the hold overlay on checkout stays undisturbed), scoped to containers that are supposed to hold just the active cart items (`#sc-active-cart`) and just the saved-for-later items (`#sc-saved-cart`) respectively — both still inferred guesses for the *container* itself, even though the item-level controls inside them are now confirmed. If a stage's container isn't found, that stage aborts and reports so rather than falling back to searching the whole page. The background tab closes itself once done, or automatically after 45 seconds either way (tracked through a Chrome alarm, so this still happens even if the extension's background process gets recycled mid-wait).

Checking **"Only alert if the cart couldn't be fully emptied"** changes when the phone/local alert fires: instead of alerting as soon as an order is held, it waits for the cleanup result — if every item was handled, nothing fires at all; you'll only hear about it if some items got left behind, cleanup didn't finish in time, or it had to abort — all three count as "not emptied." Only takes effect when cart cleanup above isn't "Do nothing."

## What happens at checkout

- Clicking (or Enter-submitting) "Place your order" is blocked before any request goes to Amazon.
- The shopper sees the on-page message — both the headline and body text are editable in Options.
- Both the **OK** button and the **&times;** in the corner navigate the tab away to a configurable URL (defaults to Gmail) once clicked — set under "OK / close sends them to" in Options. Clicking outside the card or pressing Escape just hides the message without navigating, in case that distinction matters to you; say the word if you'd rather those redirect too.
- The phone gets a push with the page URL, a timestamp, and the order total when it could be detected on the page.
- Nothing is completed or cancelled automatically — this first version deliberately stops at notify-only, so finishing or clearing the order still means opening Amazon normally. One-tap approve/deny from the notification itself is a natural next step (ntfy supports action buttons that fire HTTP requests), but it adds real complexity: Manifest V3 background scripts don't stay running continuously, so listening for that response needs extra plumbing (periodic alarms or an offscreen document) rather than a simple open connection.

## Robustness notes

- **Six redundant ways** to identify the "Place your order" control (a declarative action attribute, a test id, two element ids, and two text/attribute fallbacks) — any single match is enough, so one Amazon markup change is unlikely to disable the block outright.
- Listeners are attached to `document` in the **capturing phase**, injected at `document_start`, so they run before Amazon's own handlers regardless of where on the page a click lands. They use event delegation (checking `event.target` on every event) rather than holding a reference to one DOM node, so they keep working even when Amazon's checkout re-renders the button — common in React-style single-page apps, where the specific node a listener was attached to can get silently swapped out.
- Click, native form submit, *and* Enter-key submission from a focused field are all intercepted — clicking is the main path, but pressing Enter in a form field can submit without ever "clicking" anything.
- **The canary**: roughly every 1.5 seconds, and after every DOM mutation, the extension checks whether the current page looks like Amazon's checkout (URL pattern, `spc`-prefixed markup, or checkout-related text) and whether it can still find something matching the order control. If it looks like checkout and nothing matches for more than 5 seconds, it sends a separately-labeled alert — so a broken guard gets noticed quickly instead of just not doing anything.
- The phone push and the on-device browser notification fire independently of each other, and independently of whether the order was actually blocked — blocking happens synchronously in the page before either notification channel is contacted, so a dead phone or an unreachable ntfy server never affects whether an order goes through.

## Known limitations

- **Browser-only.** This can't intercept the Amazon mobile app, Alexa voice orders, or purchases from a browser/device that doesn't have the extension installed.
- **Order-total detection is best-effort.** It tries a few common selector/text patterns; if none match, the alert just omits the amount rather than failing anything else.
- **A genuinely new trigger mechanism** (not click, submit, or Enter) would need its own listener added — the canary catches "the control vanished," not "a new, different way to activate it appeared."
- Amazon periodically changes and A/B-tests checkout markup. If both the selectors *and* the text fallback stop matching at the same time, re-inspect the live "Place your order" button (right-click → Inspect, same as before) and update `BUTTON_SELECTORS` at the top of `content.js`.

## Files

| File | Role |
|---|---|
| `manifest.json` | Extension configuration (Manifest V3) |
| `content.js` | Interception + canary logic, runs on Amazon pages |
| `overlay.css` | Styling for the on-page hold message |
| `background.js` | Sends the local + ntfy notifications |
| `options.html/css/js` | Settings UI (also doubles as the toolbar popup) |
| `common.js` | Shared defaults used by the three scripts above |
