// Amazon Order Guard — shared constants.
// Loaded by content.js (via content_scripts), background.js (via importScripts),
// and options.html (via <script>) so all three agree on one set of defaults.

const DEFAULT_SETTINGS = {
  ntfyServer: 'https://ntfy.sh',
  ntfyTopic: '',              // intentionally blank — must be set in Options before pushes work
  alertsEnabled: true,        // master on/off for phone + local alerts on a held order (anomaly alerts always fire)
  holdTitle: 'Order submitted',
  holdBody: "Your Amazon order has been submitted.",
  redirectUrl: 'https://www.amazon.com/', // where OK / close send the shopper
  cartCleanupMode: 'save_for_later',    // 'off' | 'save_for_later' | 'wishlist'
  wishlistName: '',
  alertOnlyOnCartFailure: true, // when true (and cart cleanup isn't "off"), suppress alerts unless the cart couldn't be fully emptied
  notifyTitleHeld: 'Amazon order held for approval',
  notifyTitleAnomaly: 'Amazon Order Guard needs a manual check',
  lastEvent: null             // { type, url, timestamp, total? } — written by background.js, read by options.js
};

// A place to keep a short changelog of last N events for the options page,
// capped so storage never grows unbounded.
const MAX_EVENT_LOG = 15;
