// Amazon Order Guard — background service worker.
// Owns all outbound notification logic so content.js stays focused purely
// on detection/interception.

importScripts('common.js');

const CLEANUP_TAB_TIMEOUT_MS = 45000;

chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason === 'install') {
    chrome.runtime.openOptionsPage();
  }
});

// A plain setTimeout would be lost if this service worker gets torn down
// mid-wait (normal under Manifest V3). An alarm survives that, so it's the
// only reliable way to guarantee a stray background tab eventually closes.
chrome.alarms.create('aog-sweep-stale-tabs', { periodInMinutes: 0.5 });
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'aog-sweep-stale-tabs') sweepStaleCleanupTabs();
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || !message.type) return;

  if (message.type === 'ORDER_HELD') {
    handleOrderHeld(message.data);
  } else if (message.type === 'GUARD_ANOMALY') {
    handleAnomaly(message.data);
  } else if (message.type === 'CART_CLEANUP_RESULT') {
    handleCartCleanupResult(message.data, sender);
  } else if (message.type === 'SEND_TEST_ALERT') {
    handleTestAlert().then(sendResponse);
    return true; // keep the message channel open for the async response
  }
});

async function handleOrderHeld(data) {
  const settings = await getSettings();
  const totalText = data.total ? ` — ${data.total}` : '';
  const summary = `Held on ${hostnameOf(data.url)}${totalText} (via ${data.trigger}).`;

  await recordEvent({ type: 'held', ...data });

  const willAttemptCleanup =
    settings.cartCleanupMode !== 'off' &&
    (settings.cartCleanupMode !== 'wishlist' || !!settings.wishlistName);
  // With "only alert on cart failure" on, whether to alert at all depends on
  // how the cleanup goes — so the immediate alert here is skipped, and
  // handleCartCleanupResult() decides once it knows the outcome. If cleanup
  // isn't even running, there's no outcome to wait for, so alert as normal.
  const deferAlertToCleanupResult = willAttemptCleanup && settings.alertOnlyOnCartFailure;

  if (settings.alertsEnabled && !deferAlertToCleanupResult) {
    await pushNtfy(settings, {
      title: settings.notifyTitleHeld,
      message: `${summary}\n${data.url}`,
      priority: 4,
      tags: ['shopping_trolley']
    });
  }

  if (willAttemptCleanup) {
    openCartCleanupTab(settings.cartCleanupMode, settings.wishlistName);
  }
}

async function handleAnomaly(data) {
  // Deliberately not gated by alertsEnabled — this is "the guard itself may
  // be broken," which is a different kind of alert than "an order happened."
  const settings = await getSettings();
  const summary = `${data.reason} (${hostnameOf(data.url)})`;

  await recordEvent({ type: 'anomaly', ...data });

  await pushNtfy(settings, {
    title: settings.notifyTitleAnomaly,
    message: `${summary}\n${data.url}`,
    priority: 5,
    tags: ['warning', 'rotating_light']
  });
}

async function handleTestAlert() {
  const settings = await getSettings();
  return pushNtfy(settings, {
    title: 'Amazon Order Guard — test',
    message: 'If this reached your phone, the ntfy channel is wired up correctly.',
    priority: 3,
    tags: ['white_check_mark']
  });
}

// ---- Cart cleanup orchestration -----------------------------------------
//
// Opens a hidden background tab on the cart page with the requested mode
// (and, for wishlist mode, the target list name) encoded in the URL hash
// (content.js reads it; hash fragments are never sent to Amazon's server).
// Tracked in chrome.storage rather than an in-memory variable so a
// service-worker restart mid-flow doesn't lose track of a tab that needs
// closing.

function openCartCleanupTab(mode, wishlistName) {
  const payload = encodeURIComponent(JSON.stringify({ mode, wishlistName }));
  const url = `https://www.amazon.com/gp/cart/view.html#aog-move=${payload}`;
  chrome.tabs.create({ url, active: false }, async (tab) => {
    if (!tab || !tab.id) return;
    const { pendingCleanupTabs = {} } = await chrome.storage.local.get({ pendingCleanupTabs: {} });
    pendingCleanupTabs[tab.id] = Date.now();
    chrome.storage.local.set({ pendingCleanupTabs });
  });
}

async function handleCartCleanupResult(data, sender) {
  const tabId = sender && sender.tab && sender.tab.id;
  console.log('[Amazon Order Guard] Cart cleanup result:', data);
  await recordEvent({ type: 'cart_cleanup', ...data, timestamp: Date.now() });

  const settings = await getSettings();
  const fullyEmptied = !data.error && !data.aborted && data.addedOnly === 0 && data.failed === 0;

  // Alert here whenever alerts are on, UNLESS "only alert on cart failure"
  // is on AND the cart was in fact fully emptied — that's the one case
  // meant to stay silent.
  const shouldAlert = settings.alertsEnabled && !(settings.alertOnlyOnCartFailure && fullyEmptied);

  if (shouldAlert) {
    const title = fullyEmptied ? 'Cart cleanup finished' : 'Amazon Order Guard: cart needs manual attention';
    const summary = data.aborted
      ? data.reason === 'no_saved_root_found'
        ? "Items were saved for later, but couldn't be added to the list from there — check the Saved for later section, they're not lost."
        : data.reason === 'save_for_later_flow_not_implemented'
          ? `Found ${data.failed} cart item(s), but moving them to a wish list needs one more setup step — nothing was touched.`
          : "Couldn't find the cart items on the page — nothing was touched. The cart-cleanup selectors likely need updating."
      : data.mode === 'save_for_later'
        ? `Saved ${data.moved} item(s) for later, couldn't handle ${data.failed}.`
        : `Moved ${data.moved}, left in cart (unconfirmed) ${data.addedOnly}, couldn't handle ${data.failed}.`;

    await pushNtfy(settings, {
      title,
      message: summary,
      priority: fullyEmptied ? 3 : 5,
      tags: fullyEmptied ? ['white_check_mark'] : ['warning']
    });
  }

  if (tabId) await closeCleanupTab(tabId);
}

async function closeCleanupTab(tabId) {
  chrome.tabs.remove(tabId).catch(() => {});
  const { pendingCleanupTabs = {} } = await chrome.storage.local.get({ pendingCleanupTabs: {} });
  delete pendingCleanupTabs[tabId];
  chrome.storage.local.set({ pendingCleanupTabs });
}

async function sweepStaleCleanupTabs() {
  const { pendingCleanupTabs = {} } = await chrome.storage.local.get({ pendingCleanupTabs: {} });
  const now = Date.now();
  const stillPending = {};
  let anyClosed = false;

  for (const [tabIdStr, startedAt] of Object.entries(pendingCleanupTabs)) {
    if (now - startedAt > CLEANUP_TAB_TIMEOUT_MS) {
      chrome.tabs.remove(Number(tabIdStr)).catch(() => {});
      anyClosed = true;
    } else {
      stillPending[tabIdStr] = startedAt;
    }
  }

  if (anyClosed) {
    chrome.storage.local.set({ pendingCleanupTabs: stillPending });
    console.warn('[Amazon Order Guard] Closed a cart-cleanup tab that never reported back — check the selectors against your live cart page.');
    await recordEvent({ type: 'cart_cleanup', moved: 0, addedOnly: 0, failed: 0, timedOut: true, timestamp: now });

    // A tab that never reports back is a failure by definition, so this
    // alert ignores alertOnlyOnCartFailure's "success" branch entirely —
    // there's no success outcome here to have been silent about.
    const settings = await getSettings();
    if (settings.alertsEnabled) {
      const title = 'Amazon Order Guard: cart needs manual attention';
      const message = "Cart cleanup didn't finish in time — check your cart directly.";
      await pushNtfy(settings, { title, message, priority: 5, tags: ['warning'] });
    }
  }
}

// ---- Notification channels --------------------------------------------------

async function pushNtfy(settings, { title, message, priority, tags }) {
  console.log('[Amazon Order Guard] pushNtfy', { title, message, priority, tags });
  if (!settings.ntfyTopic) {
    console.warn('[Amazon Order Guard] No ntfy topic configured — open the extension options to set one.');
    return { ok: false, reason: 'not_configured' };
  }

  const server = settings.ntfyServer.replace(/\/+$/, '');
  const payload = { topic: settings.ntfyTopic, title, message, priority, tags };

  const attempt = async () => {
    const res = await fetch(`${server}/`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    if (!res.ok) throw new Error(`ntfy responded with ${res.status}`);
    return res;
  };

  try {
    await attempt();
    return { ok: true };
  } catch (firstError) {
    console.warn('[Amazon Order Guard] ntfy push failed once, retrying:', firstError);
    try {
      await new Promise((resolve) => setTimeout(resolve, 1200));
      await attempt();
      return { ok: true };
    } catch (secondError) {
      console.error('[Amazon Order Guard] ntfy push failed twice:', secondError);
      return { ok: false, reason: 'network', error: String(secondError) };
    }
  }
}

// ---- Storage helpers ----------------------------------------------------------

function getSettings() {
  return new Promise((resolve) => chrome.storage.sync.get(DEFAULT_SETTINGS, resolve));
}

function recordEvent(event) {
  return new Promise((resolve) => {
    chrome.storage.local.get({ eventLog: [] }, ({ eventLog }) => {
      const next = [event, ...eventLog].slice(0, MAX_EVENT_LOG);
      chrome.storage.local.set({ eventLog: next }, resolve);
    });
  });
}

function hostnameOf(url) {
  try {
    return new URL(url).hostname;
  } catch (e) {
    return url;
  }
}
