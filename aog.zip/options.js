const els = {
  form: document.getElementById('settingsForm'),
  alertsEnabled: document.getElementById('alertsEnabled'),
  ntfyServer: document.getElementById('ntfyServer'),
  ntfyTopic: document.getElementById('ntfyTopic'),
  holdTitle: document.getElementById('holdTitle'),
  holdBody: document.getElementById('holdBody'),
  redirectUrl: document.getElementById('redirectUrl'),
  cartCleanupMode: document.getElementById('cartCleanupMode'),
  wishlistName: document.getElementById('wishlistName'),
  wishlistNameField: document.getElementById('wishlistNameField'),
  alertOnlyOnCartFailure: document.getElementById('alertOnlyOnCartFailure'),
  testBtn: document.getElementById('testBtn'),
  feedback: document.getElementById('feedback'),
  statusDot: document.getElementById('statusDot'),
  statusDetail: document.getElementById('statusDetail')
};

function load() {
  chrome.storage.sync.get(DEFAULT_SETTINGS, (settings) => {
    els.alertsEnabled.checked = settings.alertsEnabled;
    els.ntfyServer.value = settings.ntfyServer;
    els.ntfyTopic.value = settings.ntfyTopic;
    els.holdTitle.value = settings.holdTitle;
    els.holdBody.value = settings.holdBody;
    els.redirectUrl.value = settings.redirectUrl;
    els.cartCleanupMode.value = settings.cartCleanupMode;
    els.wishlistName.value = settings.wishlistName;
    els.alertOnlyOnCartFailure.checked = settings.alertOnlyOnCartFailure;
    updateWishlistFieldVisibility();
    refreshStatus(settings);
  });
}

function refreshStatus(settings) {
  chrome.storage.local.get({ eventLog: [] }, ({ eventLog }) => {
    const configured = !!settings.ntfyTopic;
    els.statusDot.classList.toggle('is-off', !configured);

    if (!configured) {
      els.statusDetail.textContent = 'Not configured yet — set an ntfy topic below.';
      return;
    }
    const last = eventLog[0];
    if (!last) {
      els.statusDetail.textContent = 'Active. No orders held yet.';
      return;
    }
    const when = new Date(last.timestamp).toLocaleString();
    if (last.type === 'anomaly') {
      els.statusDetail.textContent = `Last event: interception check failed — ${when}`;
    } else if (last.type === 'cart_cleanup' && last.timedOut) {
      els.statusDetail.textContent = `Last cart cleanup: timed out, needed a manual check — ${when}`;
    } else if (last.type === 'cart_cleanup' && last.aborted) {
      els.statusDetail.textContent = `Last cart cleanup: aborted, couldn't finish — ${when}`;
    } else if (last.type === 'cart_cleanup') {
      els.statusDetail.textContent = `Last cart cleanup: handled ${last.moved}, left ${last.addedOnly}, failed ${last.failed} — ${when}`;
    } else {
      els.statusDetail.textContent = `Last held order: ${when}${last.total ? ' — ' + last.total : ''}`;
    }
  });
}

function updateWishlistFieldVisibility() {
  els.wishlistNameField.style.display = els.cartCleanupMode.value === 'wishlist' ? '' : 'none';
}

els.cartCleanupMode.addEventListener('change', updateWishlistFieldVisibility);

function showFeedback(text, kind) {
  els.feedback.textContent = text;
  els.feedback.className = `feedback feedback-${kind}`;
}

els.form.addEventListener('submit', (event) => {
  event.preventDefault();
  const settings = {
    alertsEnabled: els.alertsEnabled.checked,
    ntfyServer: els.ntfyServer.value.trim() || DEFAULT_SETTINGS.ntfyServer,
    ntfyTopic: els.ntfyTopic.value.trim(),
    holdTitle: els.holdTitle.value.trim() || DEFAULT_SETTINGS.holdTitle,
    holdBody: els.holdBody.value.trim() || DEFAULT_SETTINGS.holdBody,
    redirectUrl: els.redirectUrl.value.trim() || DEFAULT_SETTINGS.redirectUrl,
    cartCleanupMode: els.cartCleanupMode.value,
    wishlistName: els.wishlistName.value.trim(),
    alertOnlyOnCartFailure: els.alertOnlyOnCartFailure.checked
  };
  chrome.storage.sync.set(settings, () => {
    showFeedback('Saved.', 'ok');
    refreshStatus({ ...DEFAULT_SETTINGS, ...settings });
  });
});

els.testBtn.addEventListener('click', () => {
  showFeedback('Sending test alert…', 'pending');
  chrome.runtime.sendMessage({ type: 'SEND_TEST_ALERT' }, (result) => {
    if (result && result.ok) {
      showFeedback('Sent — check your phone.', 'ok');
    } else if (result && result.reason === 'not_configured') {
      showFeedback('Save an ntfy topic first.', 'error');
    } else {
      showFeedback('Could not reach the ntfy server — check the address and your connection.', 'error');
    }
  });
});

load();
